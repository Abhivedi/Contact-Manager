var selectedRow = null

document.addEventListener("DOMContentLoaded", function() {
    loadData();
});

function onFormSubmit(e) {
	event.preventDefault();
        var formData = readFormData();
        if (selectedRow == null){
            insertNewRecord(formData);
		}
        else{
            updateRecord(formData);
		}
        saveData()
        resetForm();    
}

//Retrieve the data
function readFormData() {
    var formData = {};
    formData["contact"] = document.getElementById("contact").value;
    formData["contactname"] = document.getElementById("contactname").value;
    formData["age"] = document.getElementById("age").value;
    formData["gmail"] = document.getElementById("gmail").value;
    return formData;
}

//Insert the data
function insertNewRecord(data) {
    var table = document.getElementById("storeList").getElementsByTagName('tbody')[0];
    var newRow = table.insertRow(table.length);
    cell1 = newRow.insertCell(0);
		cell1.innerHTML = data.contact;
    cell2 = newRow.insertCell(1);
		cell2.innerHTML = data.contactname;
    cell3 = newRow.insertCell(2);
		cell3.innerHTML = data.age;
    cell4 = newRow.insertCell(3);
		cell4.innerHTML = data.gmail;
    cell5 = newRow.insertCell(4);
        cell5.innerHTML = `<button onClick="onEdit(this)">Edit</button> <button onClick="onDelete(this)">Delete</button>`;
}

//Edit the data
function onEdit(td) {
    selectedRow = td.parentElement.parentElement;
    document.getElementById("contact").value = selectedRow.cells[0].innerHTML;
    document.getElementById("contactname").value = selectedRow.cells[1].innerHTML;
    document.getElementById("age").value = selectedRow.cells[2].innerHTML;
    document.getElementById("gmail").value = selectedRow.cells[3].innerHTML;
}
function updateRecord(formData) {
    selectedRow.cells[0].innerHTML = formData.contact;
    selectedRow.cells[1].innerHTML = formData.contactname;
    selectedRow.cells[2].innerHTML = formData.age;
    selectedRow.cells[3].innerHTML = formData.gmail;
    saveData();
}

//Delete the data
function onDelete(td) {
    if (confirm('Do you want to delete this record?')) {
        row = td.parentElement.parentElement;
        document.getElementById('storeList').deleteRow(row.rowIndex);
        resetForm();
        saveData();
    }
}

//Reset the data
function resetForm() {
    document.getElementById("contact").value = '';
    document.getElementById("contactname").value = '';
    document.getElementById("age").value = '';
    document.getElementById("gmail").value = '';
    selectedRow = null;
}
function saveData() {
    var table = document.getElementById("storeList").getElementsByTagName('tbody')[0];
    var rows = table.rows;
    var data = [];
    for (var i = 0; i < rows.length; i++) {
        var row = rows[i];
        var rowData = {
            "contact": row.cells[0].innerHTML,
            "contactname": row.cells[1].innerHTML,
            "age": row.cells[2].innerHTML,
            "gmail": row.cells[3].innerHTML,
        };
        data.push(rowData);
    }
    localStorage.setItem("contacts", JSON.stringify(data));
}

function loadData() {
    var data = localStorage.getItem("contacts");
    if (data) {
        var contacts = JSON.parse(data);
        for (var i = 0; i < contacts.length; i++) {
            insertNewRecord(contacts[i]);
        }
    }
}
