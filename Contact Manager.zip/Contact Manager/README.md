#Contact Manager

1 Technology

  Html.
  CSS.
  Javascript.

2  How to run ?.
  
(i)  Install Visual Studio Code & Setup with live server extention     and  Javascript.

(ii)  create folder and extract zip file.

(iii) and run project by using visual studio code.
